console.log('Save key activated. Press Cmd-S or Ctrl-S to save or update your post.')
window.onkeydown = function(e) {
	if ((e.metaKey||e.ctrlKey) && e.keyCode == 83) {
		e.preventDefault();
		jQuery('#save-post,#publish').eq(0).click()
		return false;
	}
};
