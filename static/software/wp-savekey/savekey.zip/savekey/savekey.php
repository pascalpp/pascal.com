<?php
/*
Plugin Name: Save Key
Plugin URI: http://www.pascal.com
Description: A plugin that maps Cmd-S / Ctrl-S to the save button
Version: 1.0
Author: Pascal
Author URI: http://www.pascal.com
*/
function add_savekey_handler() {
    global $parent_file;
	#echo '<script type="text/javascript">console.log("'.$parent_file.'")</script>';

    if (stristr($parent_file,'edit.php')) {
		$folder = rtrim( basename( dirname( __FILE__ ) ), '/' );
    	echo '<script type="text/javascript" src="'.WP_PLUGIN_URL.'/'.$folder.'/savekey.js"></script>';
    }
}

add_filter('admin_head', 'add_savekey_handler');

?>